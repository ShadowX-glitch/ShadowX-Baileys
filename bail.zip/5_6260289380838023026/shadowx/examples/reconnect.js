// Reference pattern only: adapt auth-state setup to the exports in this build.
// Do not reconnect indefinitely after a logged-out session.
const { DisconnectReason } = require('shadowx-baileys');

async function start(makeSocket) {
  const sock = await makeSocket();
  sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
    if (connection === 'close') {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode === DisconnectReason.loggedOut) {
        console.error('[ShadowX] Session logged out. Re-link the device before restarting.');
        return;
      }
      console.warn('[ShadowX] Connection closed; restart with backoff after checking the disconnect reason.');
    }
  });
  return sock;
}

module.exports = { start };
