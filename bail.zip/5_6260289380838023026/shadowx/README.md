# ShadowX Baileys

Custom build based on the uploaded LotusBail RC13 patched source, itself derived from WhiskeySockets Baileys.

## Requirements
- Node.js 21 or newer (the upstream source may have additional runtime requirements)
- Install dependencies with `npm install`

## Install from a GitHub repository
```bash
npm install github:YOUR_GITHUB_USERNAME/shadowx-baileys
```

## Basic usage
```js
const makeWASocket = require('shadowx-baileys').default;
const { useMultiFileAuthState, DisconnectReason } = require('shadowx-baileys');
```

Use the example matching this build's exports and the upstream Baileys documentation for authentication and connection handling. This package is a custom build, not an official WhatsApp library.

## Connection recovery
A connection-close event cannot be prevented in every situation: network interruptions, logged-out sessions, server-side changes, and WhatsApp restrictions can all close a connection. Reconnect on recoverable disconnects, and do not loop when the session is logged out.

## Optional: follow the ShadowX channel
Following a channel changes the WhatsApp account associated with the active session. It is therefore **not performed silently by default**. After the socket is connected and you choose to follow it, call:

```js
await sock.newsletterFollow('120363426086840484@newsletter');
```

Channel link: https://whatsapp.com/channel/0029Vb7fEMTGzzKN8qh8gR3y

## Feature notes
- **Message types:** support depends on the capabilities of the underlying upstream version and WhatsApp's current protocol; “all types” cannot be guaranteed.
- **Rich messages:** availability depends on upstream implementation and WhatsApp-side support.
- **Auto-update:** this package does not self-modify or silently replace its source. Update it deliberately through npm/GitHub after reviewing changes.
- **Node.js 21+:** the package metadata requires Node.js 21+, but a full runtime/test suite has not been run as part of this repackaging.

## License and attribution
This build retains the included upstream `LICENSE`. Review that license and preserve all required notices when redistributing. ShadowX is not affiliated with WhatsApp or Meta.
